import javax.swing.JOptionPane;
public class Fabrica{
	
	private Coche[] coches;
	
	public static void main(String[] args){
		
		Fabrica f = new Fabrica();
		
		Coche[] coches = new Coche[4];
		
		f.setCoches(coches);
		coches = f.getCoches();
		
		coches[0] = new Coche();
		coches[1] = new Coche("5678-AG");
		coches[2] = new Coche(5, 5);
		coches[3] = new Coche("VW", "Caddy", "blanco");
		
		coches[0].matricular("1234-DF");
		coches[2].matricular("9012-HH");
		coches[3].matricular("3456-XS");
		
		coches[3].tunear();
		
		coches[1].tunear("rojo");
		
		coches[0].avanzar(200);
		coches[1].avanzar(300);
		coches[2].avanzar(400);
		coches[3].avanzar(500);
		
		coches[0].setModelo("Toledo");
		coches[0].setColor("azul");
		
		coches[1].setMarca("FIAT");
		coches[1].setModelo("Uno");
		coches[1].setPlazas(2);
		
		coches[2].setMarca("BMW");
		coches[2].setModelo("850");
		coches[2].setColor("gris");
		
		coches[3].setPuertas(5);
		coches[3].setPlazas(7);
		
		for(int i = 0; i < coches.length; i++){
			
			caracteristicas(coches[i]);
		}
	}
	
	public static void caracteristicas(Coche coche){
		
		JOptionPane.showMessageDialog(null, "Matricula: " + coche.getMatricula() + "\n" + "Marca: " + coche.getMarca() + "\n" + "Modelo: " + coche.getModelo() + "\n" + "Color: " + coche.getColor() + "\n" + "Techo solar: " + coche.getTecho() + "\n" + "KM: " + coche.getKilometros() + "\n" + "Numero de puertas: " + coche.getPuertas() + "\n" + "Numero de plazas: " + coche.getPlazas() + "\n");
	}
	
	public void setCoches(Coche[] c){
		coches = c;
	}
	
	public Coche[] getCoches(){
		return coches;
	}
	
}