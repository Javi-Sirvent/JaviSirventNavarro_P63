import javax.swing.JOptionPane;
public class Coche{
	
	private String matricula = "";
	private String marca = "SEAT";
	private String modelo = "ALTEA";
	private String color = "blanco";
	private boolean techoSolar;
	private double kilometros;
	private int numPuertas = 3;
	private int numPlazas = 5;
	
	public void setMatricula(String m){
		matricula = m;
	}
	
	public String getMatricula(){
		return matricula;
	}
	
	public void setMarca(String m){
		marca = m;
	}
	
	public String getMarca(){
		return marca;
	}
	
	public void setModelo(String m){
		modelo = m;
	}
	
	public String getModelo(){
		return modelo;
	}
	
	public void setColor(String c){
		color = c;
	}
	
	public String getColor(){
		return color;
	}
	
	public void setTecho(boolean t){
		techoSolar = t;
	}
	
	public boolean getTecho(){
		return techoSolar;
	}
	
	public void setKilometros(double km){
		kilometros = km;
	}
	
	public double getKilometros(){
		return kilometros;
	}
	
	public void setPuertas(int n){
		if(!(n < 0 || n > 5)){
			numPuertas = n;
		}
	}
	
	public int getPuertas(){
		return numPuertas;
	}
	
	public void setPlazas(int n){
		if(!(n < 0 || n > 7)){
			numPlazas = n;
		}
	}
	
	public int getPlazas(){
		return numPlazas;
	}
	
	public Coche(){
	}
	
	public Coche(String matricula1){
		
		matricula = matricula1;
	}
	
	public Coche(int numPuertas1, int numPlazas1){
		
		if(!(numPuertas1 < 0 || numPuertas1 > 5) && !(numPlazas1 < 0 || numPlazas1 > 7)){
			
			numPuertas = numPuertas1;
			numPlazas = numPlazas1;
		}
	}
	
	public Coche(String marca1, String modelo1, String color1){
		
		marca = marca1;
		modelo = modelo1;
		color = color1;
	}
	
	public void avanzar(double kilometros1){
		
		kilometros = kilometros + kilometros1;
		
		JOptionPane.showMessageDialog(null, "Se han sumado " + kilometros1 + "KM. " + kilometros + " KM en total.");
	}
	
	public void tunear(){
		
		kilometros = 0;
		
		if(!techoSolar){
			techoSolar = true;
			
			JOptionPane.showMessageDialog(null, "Se han puesto a 0 los KM y se ha colocado un techo solar.");
		}
		else{
			
			JOptionPane.showMessageDialog(null, "Se han puesto a 0 los KM.");
		}
	}
	
	public void tunear(String color1){
		
		color = color1;
		kilometros = 0;
		
		if(!techoSolar){
			techoSolar = true;
			
			JOptionPane.showMessageDialog(null, "Se han puesto a 0 los KM, se ha colocado un techo solar y se ha pintado de " + color + ".");
		}
		else{
			
			JOptionPane.showMessageDialog(null, "Se han puesto a 0 los KM y se ha pintado de " + color + ".");
		}
	}
	
	public void matricular(String matricula1){
		
		matricula = matricula1;
		
		JOptionPane.showMessageDialog(null, "Se ha matriculado con la matricula " + matricula + ".");
	}
}