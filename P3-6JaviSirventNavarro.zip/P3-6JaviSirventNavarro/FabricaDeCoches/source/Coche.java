import javax.swing.JOptionPane;

/**
	* Crea un nuevo Coche.
	* MAX_COCHES El número máximo de coches que se pueden crear.
	* cocheCount El contador de coches creados.
	* matricula El valor de la matrícula del coche.
	* marca El valor de la marca del coche.
	* modelo El valor del modelo del coche.
	* color El valor del color del coche.
	* techoSolar El valor del techo solar del coche.
	* kilometros El valor de los kilometros del coche.
	* numPuertas El valor del número de puertas del coche.
	* numPlazas El valor del número de plazas del coche.
	@author Javi Sirvent
	*/
public class Coche{
	
	public static final int MAX_COCHES = 5;
	public static int cocheCount = 0;
	
	private String matricula;
	private String marca = "SEAT";
	private String modelo = "ALTEA";
	private String color = "blanco";
	private boolean techoSolar;
	private double kilometros;
	private int numPuertas = 3;
	private int numPlazas = 5;
	
	/**
	* Asigna la matrícula al coche.
	* @param m El valor de la variable matricula.
	*/
	public void setMatricula(String m){
		matricula = m;
	}	
	
	/**
	*Devuelve el valor de la variable matricula
	*@return El valor de la variable matricula
	*/
	public String getMatricula(){
		return matricula;
	}
	
	/**
	* Asigna la marca al coche.
	* @param m El valor de la variable marca.
	*/
	public void setMarca(String m){
		marca = m;
	}
	
	/**
	*Devuelve el valor de la variable marca
	*@return El valor de la variable marca
	*/
	public String getMarca(){
		return marca;
	}
	
	/**
	* Asigna el modelo al coche.
	* @param m El valor de la variable modelo.
	*/
	public void setModelo(String m){
		modelo = m;
	}
	
	/**
	*Devuelve el valor de la variable modelo
	*@return El valor de la variable modelo
	*/
	public String getModelo(){
		return modelo;
	}
	
	/**
	* Asigna el color al coche.
	* @param c El valor de la variable color.
	*/
	public void setColor(String c){
		color = c;
	}
	
	/**
	*Devuelve el valor de la variable color
	*@return El valor de la variable color
	*/
	public String getColor(){
		return color;
	}
	
	/**
	* Asigna el techo al coche.
	* @param t El valor de la variable techo.
	*/
	public void setTecho(boolean t){
		techoSolar = t;
	}
	
	/**
	*Devuelve el valor de la variable techoSolar
	*@return El valor de la variable techoSolar
	*/
	public boolean getTecho(){
		return techoSolar;
	}
	
	/**
	* Asigna los kilómetros al coche.
	* @param km El valor de la variable kilometros.
	*/
	public void setKilometros(double km){
		kilometros = km;
	}
	
	/**
	*Devuelve el valor de la variable kilometros
	*@return El valor de la variable kilometros
	*/
	public double getKilometros(){
		return kilometros;
	}
	
	/**
	* Asigna el número de puertas al coche.
	* @param m El valor de la variable numPuertas.
	*/
	public void setPuertas(int n){
		if(!(n < 0 || n > 5)){
			numPuertas = n;
		}
	}
	
	/**
	*Devuelve el valor de la variable numPuertas
	*@return El valor de la variable numPuertas
	*/
	public int getPuertas(){
		return numPuertas;
	}
	
	/**
	* Asigna el número de plazas al coche.
	* @param m El valor de la variable numPlazas.
	*/
	public void setPlazas(int n){
		if(!(n < 0 || n > 7)){
			numPlazas = n;
		}
	}
	
	/**
	*Devuelve el valor de la variable numPlazas
	*@return El valor de la variable numPlazas
	*/
	public int getPlazas(){
		return numPlazas;
	}
	
	/**
	* Crea un coche nuevo si el contador es menor o igual que 5.
	*/
	public Coche(){
		if(cocheCount <= 5){
			cocheCount++;
		}
	}
	
	/**
	* Crea un coche nuevo si el contador es menor o igual que 5.
	@param matricula1 valor de la variable matricula del coche creado.
	*/
	public Coche(String matricula1){
		if(cocheCount <= 5){
			matricula = matricula1;
			cocheCount++;
		}
	}
	
	/**
	* Crea un coche nuevo si el contador es menor o igual que 5.
	* @param numPuertas1 valor de la variable numPuertas del coche creado.
	* @param numPlazas1 valor de la variable numPlazas del coche creado.
	*/
	public Coche(int numPuertas1, int numPlazas1){
		if(cocheCount <= 5){
			if(!(numPuertas1 < 0 || numPuertas1 > 5) && !(numPlazas1 < 0 || numPlazas1 > 7)){
			
				numPuertas = numPuertas1;
				numPlazas = numPlazas1;
			
				cocheCount++;
			}
		}
	}
	
	/**
	* Crea un coche nuevo si el contador es menor o igual que 5.
	* @param marca1 valor de la variable marca del coche creado.
	* @param modelo1 valor de la variable modelo del coche creado.
	* @param color1 valor de la variable color del coche creado.
	*/
	public Coche(String marca1, String modelo1, String color1){
		if(cocheCount <= 5){
			marca = marca1;
			modelo = modelo1;
			color = color1;
			cocheCount++;
		}
	}
	
	/**
	* Añade los kilómetros al coche.
	* @param kilometros1 El valor de los kilómetros añadidos.
	*/
	public void avanzar(double kilometros1){
		
		kilometros = kilometros + kilometros1;
	}
	
	/**
	* Pone los kilómetros a 0 y le añade un techo solar si no lo tenía ya.
	*/
	public void tunear(){
		
		kilometros = 0;
		
		if(!techoSolar){
			techoSolar = true;
		}
	}
	
	/**
	* Pone los kilómetros a 0, le añade un techo solar si no lo tenía ya y lo pinta del color pasado por parámetro.
	* @param color1 El valor de la variable color.
	*/
	public void tunear(String color1){
		
		color = color1;
		kilometros = 0;
		
		if(!techoSolar){
			techoSolar = true;	
		}
	}
	
	/**
	* Asigna la matrícula al coche.
	* @param matricula1 El valor de la variable matricula.
	*/
	public void matricular(String matricula1){
		
		matricula = matricula1;
		
	}
}