import javax.swing.JOptionPane;

/**
* Permite crear y modificar objetos de la clase Coche.
* @author Javi Sirvent.
*/
public class Fabrica{
	
	/**
	* Método principal.
	* @param args.
	*/
	public static void main(String[] args){
		
		Coche[] coches = new Coche[Coche.MAX_COCHES];
		
		int op = 0;
		int i = 0;
		int indice = 0;
		double kilometro;
		String matri;
		String mensaje = "No puedes crear mas coches porque ya has alcanzado el maximo disponible en el almacen.";
		String mensaje2 = "No existe ningun coche con esa matricula.";
		
		do{
		
			try { String opcion = JOptionPane.showInputDialog(null, "Fabrica de Coches de Javi Sirvent Navarro. Selecciona una de las siguientes opciones: \n" + "1.Fabricar coche (conociendo matricula)\n" + "2.Fabricar coche (a partir del numero de puertas y el numero de plazas\n" + "3.Fabricar coche (a partir de la marca, el modelo y el color\n" + "4.Fabricar coche (sin datos)\n" + "5.Tunear coche (pintandolo de un color)\n" + "6.Tunear coche (sin parametro)\n" + "7.Avanzar kilometros\n" + "8.Mostrar caracteristicas de un coche\n" + "9.Salir del programa");;
				op = Integer.parseInt(opcion);
				switch (op){
					case 1:	if(Coche.cocheCount == 5){
								JOptionPane.showMessageDialog(null, mensaje);
								}
							else{
								String mat = JOptionPane.showInputDialog("Introduce la matricula: ");
								coches[Coche.cocheCount] = new Coche(mat);
								caracteristicas(coches[Coche.cocheCount - 1]); 
							}
							break;
					case 2:	if(Coche.cocheCount == 5){
								JOptionPane.showMessageDialog(null, mensaje);
								}
							else{
								String puer = JOptionPane.showInputDialog("Introduce el numero de puertas: ");
								String plaz = JOptionPane.showInputDialog("Introduce el numero de plazas: ");
								int puertas = Integer.parseInt(puer);
								int plazas = Integer.parseInt(plaz);
								coches[Coche.cocheCount] = new Coche(puertas, plazas);
								matAleatorio(coches[Coche.cocheCount - 1]);
								caracteristicas(coches[Coche.cocheCount - 1]); 
							}
					break;
					case 3: if(Coche.cocheCount == 5){
								JOptionPane.showMessageDialog(null, mensaje);
								}
							else{
								String mar = JOptionPane.showInputDialog("Introduce la marca: ");
								String mod = JOptionPane.showInputDialog("Introduce el modelo: ");
								String col = JOptionPane.showInputDialog("Introduce el color: ");
								coches[Coche.cocheCount] = new Coche(mar, mod, col);
								matAleatorio(coches[Coche.cocheCount - 1]);
								caracteristicas(coches[Coche.cocheCount - 1]); 
							}
					break;
					case 4: if(Coche.cocheCount == 5){
								JOptionPane.showMessageDialog(null, mensaje);
								}
							else{
								coches[Coche.cocheCount] = new Coche();
								matAleatorio(coches[Coche.cocheCount - 1]);
								caracteristicas(coches[Coche.cocheCount - 1]); 
							}
					break;
					case 5: matri = JOptionPane.showInputDialog("Introduce la matricula: ");
							indice = buscaCoche(coches, matri);
							if(indice == -1){
								JOptionPane.showMessageDialog(null, mensaje2);
							}
							else{
								String color = JOptionPane.showInputDialog("Introduce el color: ");
								coches[indice].tunear(color);
								caracteristicas(coches[indice]);
							}
					break;
					case 6: matri = JOptionPane.showInputDialog("Introduce la matricula: ");
							indice = buscaCoche(coches, matri);
							if(indice == -1){
								JOptionPane.showMessageDialog(null, mensaje2);
							}
							else{
								coches[indice].tunear();
								caracteristicas(coches[indice]);
							}
					break;
					case 7: matri = JOptionPane.showInputDialog("Introduce la matricula: ");
							indice = buscaCoche(coches, matri);
							if(indice == -1){
								JOptionPane.showMessageDialog(null, mensaje2);
							}
							else{
								String km = JOptionPane.showInputDialog("Introduce los km: ");
								kilometro = Double.parseDouble(km);
								coches[indice].avanzar(kilometro);
								JOptionPane.showMessageDialog(null, "Se han sumado " + kilometro + "KM. " + coches[indice].getKilometros() + " KM en total.");
								caracteristicas(coches[indice]);
							}
					break;
					case 8: matri = JOptionPane.showInputDialog("Introduce la matricula: ");
							indice = buscaCoche(coches, matri);
							if(indice == -1){
								JOptionPane.showMessageDialog(null, mensaje2);
							}
							else{
								caracteristicas(coches[indice]);
							}
					break;
					case 9: JOptionPane.showMessageDialog(null, "Gracias por usar nuestra fabrica. Hasta la proxima.");
					break;
					case 0: default: JOptionPane.showMessageDialog(null, "Introduce un numero entero entre 1 y 9.");
					break;
				}
			}
			catch (Exception localException) {
			JOptionPane.showMessageDialog(null, "Introduce un valor numerico");
			}
		}while(op != 9);
	}
	
	/**
	* Genera una matrícula aleatoria para un coche.
	* @param coche es una referencia a un objeto Coche.
	*/
	public static void matAleatorio(Coche coche){
		String mat = Integer.toString((int) (Math.random() * 100000));
		coche.setMatricula(mat);
	}
	
	/**
	* Busca y comprueba si un coche existe según su matrícula dentro de la referencia al array que obtiene por parámetro.
	* @param c Es un a referencia a un array de objetos Coche.
	* @param matricula Es el valor de la variable matricula de un objeto Coche.
	* @return j Devuelve la posición en la que se encuentra el coche cuya matrícula coincide o -1 si no lo encuentra.
	*/
	public static int buscaCoche(Coche[] c, String matricula){
		boolean prueba = true;
		int j = -1;
		if(!matricula.equals(null)){
			for(int i = 0; i < Coche.cocheCount && prueba; i++){
				String mat = c[i].getMatricula();
				if(mat.equals(matricula)){
					prueba = false;
					j = i;
				}
			}
		}
		return j;
	}
	
	/**
	* Muestra todas las características de un coche.
	* @param coche Es la referencia a un objeto Coche.
	*/
	public static void caracteristicas(Coche coche){
		
		JOptionPane.showMessageDialog(null, "Matricula: " + coche.getMatricula() + "\n" + "Marca: " + coche.getMarca() + "\n" + "Modelo: " + coche.getModelo() + "\n" + "Color: " + coche.getColor() + "\n" + "Techo solar: " + coche.getTecho() + "\n" + "KM: " + coche.getKilometros() + "\n" + "Numero de puertas: " + coche.getPuertas() + "\n" + "Numero de plazas: " + coche.getPlazas() + "\n");
	}
	
}